let NavBtn = document.querySelector(".nav__btn");
let links = document.querySelector("#links");

NavBtn.addEventListener("click", (e) => {

    links.classList.toggle("active");
    links.style.transition = ".35s cubic-bezier(0.165, 0.84, 0.44, 1);";

    e.preventDefault();

});