/* 
APP NAME: GPA CALCULATOR
APP VERSION: 1.0.0
AUTHOR: ALIYU WADA
CONTACT: aleeyuwada01@gmail.com

*/

// Storage controller
const StorageCtrl = (function() {

    return {

        setData: function(item) {

            let items;

            if(localStorage.getItem("gpa") === null) {

                items = [];

                items.push(item);

                localStorage.setItem("gpa", JSON.stringify(items))

            } else {

                items = [];

                items = JSON.parse(localStorage.getItem("gpa"));

                items.push(item);

                localStorage.setItem("gpa", JSON.stringify(items));

            }

        },

        getData: function() {

            let items;

            if(localStorage.getItem("gpa") === null) {

                items = [];

            } else {

                items = JSON.parse(localStorage.getItem("gpa"));

            }

            return items;

        }

    }

})();

// UI Controller
const UICtrl = (function() {

    // DOM strings (Selectors)
    const UISelectors = {
        addCourse: "#add-course",
        formGroup: ".calculator__form-group",
        group: ".calculator__group",
        addSemester: "#add-semester",
        course: "#course",
        grade: "#grade",
        credit: "#credit",
        simpleGpa: "#simple-gpa",
        standardGpa: ".standard-mark",
        courseCount: "#count",
        clearBtn: "#clearBtn"
    }

    // Resolve the courses, grades and the credit units
    const resolveCourseItem = function() {

        var courseName, grade, credit,  courses, grades, credits;

        // Select all the courses
        courseName = document.querySelectorAll(UISelectors.course);
        grade = document.querySelectorAll(UISelectors.grade);
        credit = document.querySelectorAll(UISelectors.credit);

        // Insert the result of the foreach into an empty array
        courses = [];
        grades = [];
        credits = [];

        // Looping through the courses Nodelist
        courseName.forEach(val => {
            // Push the result into an empty array
            courses.push(val.value);
        });

        // Looping through the courses Nodelist
        grade.forEach(val => {
            // Push the result into an empty array
            grades.push(val.value);
        });

        // Looping through the courses Nodelist
        credit.forEach(val => {
            // Push the result into an empty array
            credits.push(val.value);
        });

        return {
            courses,
            grades,
            credits
        }
    }

    return {
        getSelectors: function() {
            return UISelectors;
        },
        generateCourse: function() {
            
            // Creating text input for course name
            const inputText = document.createElement("input");
            inputText.style.width = "50%";
            inputText.type = "text";
            inputText.placeholder = "Course name";
            inputText.id = "course";
            inputText.className = "calculator__input";

            // Creating select el for grades
            const select = document.createElement("select");
            select.id = "grade";
            select.className = "calculator__input";

            // Create option els
            const optionGrade = document.createElement("option");
             optionGrade.value = "";
             optionGrade.appendChild(document.createTextNode("Grade"));
            const optionA = document.createElement("option");
             optionA.value = "5";
             optionA.appendChild(document.createTextNode("A"));
            const optionB = document.createElement("option");
             optionB.value = "4";
             optionB.appendChild(document.createTextNode("B"));
            const optionC = document.createElement("option");
             optionC.value = "3";
             optionC.appendChild(document.createTextNode("C"));
            const optionD = document.createElement("option");
             optionD.value = "2";
             optionD.appendChild(document.createTextNode("D"));
            const optionE = document.createElement("option");
             optionE.value = "1";
             optionE.appendChild(document.createTextNode("E"));
            const optionF = document.createElement("option");
             optionF.value = "0";
             optionF.appendChild(document.createTextNode("F"));

            let options = [optionGrade, optionA, optionB, optionC, optionD, optionE, optionF];

            options.forEach(val => {

                // Add options to select el
                select.appendChild(val);

            });

            // Creating number input for credit units
            const inputNumber = document.createElement("input");
            inputNumber.type = "number";
            inputNumber.placeholder = "Credit unit";
            inputNumber.id = "credit";
            inputNumber.className = "calculator__input";

            // Creating the div to insert the elements into
            const divGroup = document.createElement("div");
            divGroup.className = "calculator__group";

            // Inserting the elements inside the divGroup el
            let els = [inputText, select, inputNumber];

            els.forEach(val => {

                divGroup.insertAdjacentElement("beforeend", val);

            });

            // Insert all of the to the UI
            document.querySelector(UISelectors.formGroup).insertAdjacentElement("beforeend", divGroup);

        },
        getCourseItem: function() {

            return resolveCourseItem();
            
        },
        addGpa: function(gpa) {

            let dots = [".","..","..."];
            let count = 0;
            let random;

            function loading() {

                if(count >= 30) {
                    clearTimeout(sim);
                }

                count++;

                random = Math.floor(Math.random() * 3);
                // give some messgae for it finsihes calculating
                document.querySelector(UISelectors.simpleGpa).innerHTML = "GPA: " + "Calc" + dots[random];

                document.querySelector(UISelectors.standardGpa).textContent = "Calc" + dots[random];

            }

            var sim = setInterval(loading, 50);

            setTimeout(() => {
                // get the Gpa el
                document.querySelector(UISelectors.simpleGpa).innerHTML = "GPA: " + gpa;

                document.querySelector(UISelectors.standardGpa).textContent = gpa;
            }, 2500);
            
            if(gpa >= 1.5) {
                document.querySelector("#progress").insertAdjacentHTML("beforebegin", `<style> .st1 { stroke: #2ECEB6; stroke-dashoffset: calc(440 - (1208 * ${gpa} / 100));  } </style>`);
            } else {
                document.querySelector("#progress").insertAdjacentHTML("beforebegin", `<style> .st1 { stroke: orangered; stroke-dashoffset: calc(440 - (1208 * ${gpa} / 100));  } </style>`);
            }

        },
        courseCount: function() {

            let count = document.querySelector(UISelectors.formGroup).children.length;

            document.querySelector(UISelectors.courseCount).textContent = count;

        },
        clearCourses: function() {

            document.querySelector(UISelectors.formGroup).innerHTML = `
            <div class="calculator__group">
                            <input type="text" placeholder="Course name" id="course" class="calculator__input">
                            <select id="grade" class="calculator__input">
                                <option value="">Grade</option>
                                <option value="5">A</option>
                                <option value="4">B</option>
                                <option value="3">C</option>
                                <option value="2">D</option>
                                <option value="1">E</option>
                                <option value="0">F</option>
                            </select>
                            <input type="number" placeholder="Credit unit" id="credit" class="calculator__input">
                        </div>
                        <div class="calculator__group">
                            <input type="text" placeholder="Course name" id="course" class="calculator__input">
                            <select id="grade" class="calculator__input">
                                <option value="">Grade</option>
                                <option value="5">A</option>
                                <option value="4">B</option>
                                <option value="3">C</option>
                                <option value="2">D</option>
                                <option value="1">E</option>
                                <option value="0">F</option>
                            </select>
                            <input type="number" placeholder="Credit unit" id="credit" class="calculator__input">
                        </div>
                        <div class="calculator__group">
                            <input type="text" placeholder="Course name" id="course" class="calculator__input">
                            <select id="grade" class="calculator__input">
                                <option value="">Grade</option>
                                <option value="5">A</option>
                                <option value="4">B</option>
                                <option value="3">C</option>
                                <option value="2">D</option>
                                <option value="1">E</option>
                                <option value="0">F</option>
                            </select>
                            <input type="number" placeholder="Credit unit" id="credit" class="calculator__input">
                        </div>
                        <div class="calculator__group">
                            <input type="text" placeholder="Course name" id="course" class="calculator__input">
                            <select id="grade" class="calculator__input">
                                <option value="">Grade</option>
                                <option value="5">A</option>
                                <option value="4">B</option>
                                <option value="3">C</option>
                                <option value="2">D</option>
                                <option value="1">E</option>
                                <option value="0">F</option>
                            </select>
                            <input type="number" placeholder="Credit unit" id="credit" class="calculator__input">
                        </div>
                        <div class="calculator__group">
                            <input type="text" placeholder="Course name" id="course" class="calculator__input">
                            <select id="grade" class="calculator__input">
                                <option value="">Grade</option>
                                <option value="5">A</option>
                                <option value="4">B</option>
                                <option value="3">C</option>
                                <option value="2">D</option>
                                <option value="1">E</option>
                                <option value="0">F</option>
                            </select>
                            <input type="number" placeholder="Credit unit" id="credit" class="calculator__input">
                        </div>
            `;

        },
        clearGpa: function() {

            // Set all the values to Default
            document.querySelector(UISelectors.simpleGpa).textContent = "GPA: 0";
            document.querySelector(UISelectors.standardGpa).textContent = "0.00";
            document.querySelector("#progress").insertAdjacentHTML("beforebegin", `<style> .st1 { stroke-dashoffset: calc(440 - (1208 * 0 / 100));  } </style>`);

        }
    }

})();

// UI Controller
const GpaCtrl = (function() {

    // Setting up our datastructure
    const data = {
        courseName: [],
        grades: [],
        credits: [],
        gpa: 0
    }

    return {
        calculateGpa: function(courseItem) {

            let gpa;
            let sum = 0;
            let totalCredits = 0;
            let sumArr = [];

            // Add the courseName to our datastructure
            data.courseName.push(courseItem.courses);

            // Add the grades to our datastructure
            data.grades.push(courseItem.grades);

            // Add the credits to our datastructure
            data.credits.push(courseItem.credits);

            for (var i = 0; i < courseItem.credits.length; i++) {

                // Calculating the totalCredits
                totalCredits += parseInt(courseItem.credits);

                sumArr.push((parseInt(courseItem.credits[i]) * parseInt(courseItem.grades[i])));

            }

            // Loop through the sum array and add it
            sumArr.forEach(val => {

                sum += val;

            });

            // Calculating the Gpa
            gpa = sum / totalCredits;
            gpa  = gpa.toFixed(2);

            // Add the gpa to our datastructure
            data.gpa = gpa;

            return data.gpa;
        },
        testing: function() {
            return data;
        }
    }

})();

// UI Controller
const App = (function(StorageCtrl, UICtrl, GpaCtrl) {

    // Setting up All event listeners
    const loadeventListeners = function() {

        const UISelectors = UICtrl.getSelectors();

        // Add course event listener
        document.querySelector(UISelectors.addCourse).addEventListener("click", addCourse);

        // Get the semester
        document.querySelector(UISelectors.addSemester).addEventListener("click", addSemester);

        // Clear Courses
        document.querySelector(UISelectors.clearBtn).addEventListener("click", clearCourses);

    }

    // Addcourse function
    const addCourse = function(e) {

        UICtrl.generateCourse();

        UICtrl.courseCount();

        e.preventDefault();
    }

    // AddSemester function
    const addSemester = function(e) {

        const courseItem = UICtrl.getCourseItem();
        const gpa = GpaCtrl.calculateGpa(courseItem);

        if(courseItem.grades.includes("") || courseItem.credits.includes("") || courseItem.courses.includes("ll")) {
            alert("You do not fill-in all the inputs (some input(s) are empty check again)!");
        } else {
            UICtrl.addGpa(gpa);
        }

        // Add items to our datastructure
        let items = GpaCtrl.testing();
        StorageCtrl.setData(items);

        e.preventDefault();
    }

    // Clear courses eventListener
    const clearCourses = function(e) {

        UICtrl.clearCourses();

        UICtrl.courseCount();

        UICtrl.clearGpa();

        e.preventDefault();

    }

    return {

        init: function() {

            let data = StorageCtrl.getData();

            loadeventListeners();

        }

    }

})(StorageCtrl, UICtrl, GpaCtrl);

App.init();